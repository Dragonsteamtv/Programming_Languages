from Chef import Chef
from ChineseChef import ChineseChef
#the two above are importing the two classes from the differnet chef files

myChef = Chef()
myChef.make_chicken()

myChineseChef = ChineseChef()
myChineseChef.make_special_dish()