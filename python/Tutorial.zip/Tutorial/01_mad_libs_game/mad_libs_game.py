color = input ("Enter a color: ")
plural_noun = input ("Enter a plural noun: ")
celebrity = input ("Enter a celebrity: ")


print ("Roses are " + color)
print (plural_noun + "are blue")
print ("I love " + celebrity)


















