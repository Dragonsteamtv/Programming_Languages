class Question:
    def __init__(self, prompt, answer): #this takes two inputs: the prompt and the answer
        self.prompt = prompt 
        self.answer = answer
        #these two variables are just equal to their input