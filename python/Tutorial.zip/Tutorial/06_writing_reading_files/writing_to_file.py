employee_file = open("employes.txt", "w")
employee_file.write("\nKelly - Customuer Service")
employee_file.close()

employee_file = open("employes1.txt", "w")
employee_file.write("\nKelly - Customuer Service")
employee_file.close()

